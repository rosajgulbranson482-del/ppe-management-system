import type React from "react"
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "نظام إدارة معدات الحماية الشخصية",
  description: "نظام شامل لإدارة معدات الحماية الشخصية وتتبع توزيعها على الموظفين",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  )
}
