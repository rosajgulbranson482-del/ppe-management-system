"use client"

import { useState, useEffect } from "react"
import LoginPage from "@/components/LoginPage"
import MainApp from "@/components/MainApp"
import type { User, Employee, InventoryItem, Assignment, Settings } from "@/types"

export default function Home() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [employees, setEmployees] = useState<Employee[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [assignments, setAssignments] = useState<Assignment[]>([])
  const [settings, setSettings] = useState<Settings>({
    companyName: "شركتي",
    lowStockThreshold: 10,
    notificationEmail: "admin@example.com",
  })

  // Load data from localStorage on component mount
  useEffect(() => {
    loadDataFromLocalStorage()
  }, [])

  const loadDataFromLocalStorage = () => {
    if (typeof window !== "undefined") {
      const savedData = localStorage.getItem("ppeManagementData")
      if (savedData) {
        const data = JSON.parse(savedData)
        setEmployees(data.employees || [])
        setInventory(data.inventory || [])
        setAssignments(data.assignments || [])
        setSettings(data.settings || settings)
      }
    }
  }

  const saveDataToLocalStorage = () => {
    if (typeof window !== "undefined") {
      const data = {
        employees,
        inventory,
        assignments,
        settings,
      }
      localStorage.setItem("ppeManagementData", JSON.stringify(data))
    }
  }

  // Save data whenever state changes
  useEffect(() => {
    saveDataToLocalStorage()
  }, [employees, inventory, assignments, settings])

  const handleLogin = (username: string, password: string) => {
    if (username === "admin" && password === "admin123") {
      const user: User = {
        id: 1,
        username: "admin",
        name: "مدير النظام",
        email: "admin@example.com",
        role: "admin",
      }
      setCurrentUser(user)
      return true
    }
    return false
  }

  const handleLogout = () => {
    setCurrentUser(null)
  }

  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} />
  }

  return (
    <MainApp
      currentUser={currentUser}
      employees={employees}
      setEmployees={setEmployees}
      inventory={inventory}
      setInventory={setInventory}
      assignments={assignments}
      setAssignments={setAssignments}
      settings={settings}
      setSettings={setSettings}
      onLogout={handleLogout}
    />
  )
}
