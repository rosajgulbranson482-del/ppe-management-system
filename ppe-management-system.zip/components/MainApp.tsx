"use client"

import { useState } from "react"
import Sidebar from "./Sidebar"
import Dashboard from "./Dashboard"
import EmployeesPage from "./EmployeesPage"
import InventoryPage from "./InventoryPage"
import AssignmentsPage from "./AssignmentsPage"
import ReportsPage from "./ReportsPage"
import SettingsPage from "./SettingsPage"
import type { User, Employee, InventoryItem, Assignment, Settings } from "@/types"

interface MainAppProps {
  currentUser: User
  employees: Employee[]
  setEmployees: (employees: Employee[]) => void
  inventory: InventoryItem[]
  setInventory: (inventory: InventoryItem[]) => void
  assignments: Assignment[]
  setAssignments: (assignments: Assignment[]) => void
  settings: Settings
  setSettings: (settings: Settings) => void
  onLogout: () => void
}

export default function MainApp({
  currentUser,
  employees,
  setEmployees,
  inventory,
  setInventory,
  assignments,
  setAssignments,
  settings,
  setSettings,
  onLogout,
}: MainAppProps) {
  const [currentPage, setCurrentPage] = useState("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard employees={employees} inventory={inventory} assignments={assignments} settings={settings} />
      case "employees":
        return <EmployeesPage employees={employees} setEmployees={setEmployees} assignments={assignments} />
      case "inventory":
        return <InventoryPage inventory={inventory} setInventory={setInventory} settings={settings} />
      case "assignments":
        return (
          <AssignmentsPage
            employees={employees}
            inventory={inventory}
            setInventory={setInventory}
            assignments={assignments}
            setAssignments={setAssignments}
            settings={settings}
          />
        )
      case "reports":
        return <ReportsPage inventory={inventory} assignments={assignments} />
      case "settings":
        return <SettingsPage settings={settings} setSettings={setSettings} />
      default:
        return <Dashboard employees={employees} inventory={inventory} assignments={assignments} settings={settings} />
    }
  }

  return (
    <div className="min-h-screen bg-gray-100" dir="rtl">
      <Sidebar
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        currentUser={currentUser}
        onLogout={onLogout}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
      />

      <div className="lg:mr-64">
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between px-4 py-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>

            <div className="flex items-center space-x-4 space-x-reverse">
              <span className="text-sm text-gray-700">{currentUser.name}</span>
              <button onClick={onLogout} className="text-sm text-gray-500 hover:text-gray-700">
                تسجيل الخروج
              </button>
            </div>
          </div>
        </header>

        <main className="p-6">{renderCurrentPage()}</main>
      </div>
    </div>
  )
}
