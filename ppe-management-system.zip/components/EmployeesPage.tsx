"use client"

import { useState } from "react"
import type { Employee, Assignment } from "@/types"

interface EmployeesPageProps {
  employees: Employee[]
  setEmployees: (employees: Employee[]) => void
  assignments: Assignment[]
}

export default function EmployeesPage({ employees, setEmployees, assignments }: EmployeesPageProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)
  const [newEmployee, setNewEmployee] = useState({
    name: "",
    company: "",
    title: "",
    tel: "",
    shift: "صباحي",
    status: "Active",
  })

  const filteredEmployees = employees.filter(
    (employee) =>
      employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.title.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusText = (status: string) => {
    switch (status) {
      case "Active":
        return "نشط"
      case "Inactive":
        return "غير نشط"
      case "Left":
        return "ترك العمل"
      default:
        return status
    }
  }

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800"
      case "Inactive":
        return "bg-gray-100 text-gray-800"
      case "Left":
        return "bg-red-100 text-red-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  const handleAddEmployee = () => {
    if (!newEmployee.name || !newEmployee.company || !newEmployee.title) {
      alert("يرجى تعبئة الحقول المطلوبة")
      return
    }

    const employee: Employee = {
      id: employees.length > 0 ? Math.max(...employees.map((e) => e.id)) + 1 : 1,
      ...newEmployee,
    }

    setEmployees([...employees, employee])
    setNewEmployee({
      name: "",
      company: "",
      title: "",
      tel: "",
      shift: "صباحي",
      status: "Active",
    })
    setShowAddModal(false)
    alert("تمت إضافة الموظف بنجاح")
  }

  const handleEditEmployee = (employee: Employee) => {
    setEditingEmployee(employee)
    setNewEmployee({
      name: employee.name,
      company: employee.company,
      title: employee.title,
      tel: employee.tel || "",
      shift: employee.shift || "صباحي",
      status: employee.status || "Active",
    })
    setShowAddModal(true)
  }

  const handleUpdateEmployee = () => {
    if (!editingEmployee) return

    const updatedEmployees = employees.map((emp) => (emp.id === editingEmployee.id ? { ...emp, ...newEmployee } : emp))

    setEmployees(updatedEmployees)
    setEditingEmployee(null)
    setNewEmployee({
      name: "",
      company: "",
      title: "",
      tel: "",
      shift: "صباحي",
      status: "Active",
    })
    setShowAddModal(false)
    alert("تم تحديث بيانات الموظف بنجاح")
  }

  const handleDeleteEmployee = (employeeId: number) => {
    if (!confirm("هل أنت متأكد من حذف هذا الموظف؟")) return

    setEmployees(employees.filter((emp) => emp.id !== employeeId))
    alert("تم حذف الموظف بنجاح")
  }

  const showEmployeeDetails = (employee: Employee) => {
    setSelectedEmployee(employee)
  }

  if (selectedEmployee) {
    const employeeAssignments = assignments.filter((a) => a.employeeId === selectedEmployee.id)

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-900">تفاصيل الموظف</h1>
          <button
            onClick={() => setSelectedEmployee(null)}
            className="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600"
          >
            العودة إلى قائمة الموظفين
          </button>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">البيانات الأساسية</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p>
                <strong>اسم الموظف:</strong> {selectedEmployee.name}
              </p>
              <p>
                <strong>الشركة:</strong> {selectedEmployee.company}
              </p>
              <p>
                <strong>المسمى الوظيفي:</strong> {selectedEmployee.title}
              </p>
            </div>
            <div>
              <p>
                <strong>رقم الهاتف:</strong> {selectedEmployee.tel || "غير متوفر"}
              </p>
              <p>
                <strong>الوردية:</strong> {selectedEmployee.shift}
              </p>
              <p>
                <strong>الحالة:</strong> {getStatusText(selectedEmployee.status)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold">المعدات المسلمة</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">اسم المعدة</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المقاس</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الكمية</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">تاريخ التسليم</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {employeeAssignments.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
                      لا توجد معدات مسلمة لهذا الموظف
                    </td>
                  </tr>
                ) : (
                  employeeAssignments.map((assignment, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.itemName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.size}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.quantity}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.date}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">إدارة الموظفين</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          إضافة موظف
        </button>
      </div>

      {/* Search */}
      <div className="bg-white rounded-lg shadow p-4">
        <input
          type="text"
          placeholder="ابحث عن موظف..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Employees Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الاسم</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الشركة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الوظيفة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredEmployees.map((employee) => (
              <tr key={employee.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    onClick={() => showEmployeeDetails(employee)}
                    className="text-blue-600 hover:text-blue-800 font-medium"
                  >
                    {employee.name}
                  </button>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employee.company}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{employee.title}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeClass(employee.status)}`}
                  >
                    {getStatusText(employee.status)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2 space-x-reverse">
                  <button
                    onClick={() => handleEditEmployee(employee)}
                    className="text-yellow-600 hover:text-yellow-900"
                  >
                    تعديل
                  </button>
                  <button onClick={() => handleDeleteEmployee(employee.id)} className="text-red-600 hover:text-red-900">
                    حذف
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">{editingEmployee ? "تعديل بيانات الموظف" : "إضافة موظف جديد"}</h2>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="اسم الموظف"
                value={newEmployee.name}
                onChange={(e) => setNewEmployee({ ...newEmployee, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="text"
                placeholder="الشركة"
                value={newEmployee.company}
                onChange={(e) => setNewEmployee({ ...newEmployee, company: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="text"
                placeholder="المسمى الوظيفي"
                value={newEmployee.title}
                onChange={(e) => setNewEmployee({ ...newEmployee, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="text"
                placeholder="رقم الهاتف"
                value={newEmployee.tel}
                onChange={(e) => setNewEmployee({ ...newEmployee, tel: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <select
                value={newEmployee.shift}
                onChange={(e) => setNewEmployee({ ...newEmployee, shift: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="صباحي">صباحي</option>
                <option value="مسائي">مسائي</option>
                <option value="ليلي">ليلي</option>
              </select>

              <select
                value={newEmployee.status}
                onChange={(e) => setNewEmployee({ ...newEmployee, status: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Active">نشط</option>
                <option value="Inactive">غير نشط</option>
                <option value="Left">ترك العمل</option>
              </select>
            </div>

            <div className="flex justify-end space-x-2 space-x-reverse mt-6">
              <button
                onClick={() => {
                  setShowAddModal(false)
                  setEditingEmployee(null)
                  setNewEmployee({
                    name: "",
                    company: "",
                    title: "",
                    tel: "",
                    shift: "صباحي",
                    status: "Active",
                  })
                }}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                إلغاء
              </button>
              <button
                onClick={editingEmployee ? handleUpdateEmployee : handleAddEmployee}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                {editingEmployee ? "حفظ التعديلات" : "إضافة"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
