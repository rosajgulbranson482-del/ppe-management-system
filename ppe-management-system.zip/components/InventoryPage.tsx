"use client"

import { useState } from "react"
import type { InventoryItem, Settings } from "@/types"

interface InventoryPageProps {
  inventory: InventoryItem[]
  setInventory: (inventory: InventoryItem[]) => void
  settings: Settings
}

export default function InventoryPage({ inventory, setInventory, settings }: InventoryPageProps) {
  const [showAddModal, setShowAddModal] = useState(false)
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null)
  const [newItem, setNewItem] = useState({
    itemName: "",
    type: "",
    size: "",
    stockIn: 0,
  })

  const getStatusText = (status: string) => {
    switch (status) {
      case "Good":
        return "جيد"
      case "Low Stock":
        return "مخزون منخفض"
      case "Out of Stock":
        return "منتهي"
      default:
        return status
    }
  }

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "Good":
        return "bg-green-100 text-green-800"
      case "Low Stock":
        return "bg-yellow-100 text-yellow-800"
      case "Out of Stock":
        return "bg-red-100 text-red-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  const getRowClass = (status: string) => {
    switch (status) {
      case "Low Stock":
        return "bg-yellow-50"
      case "Out of Stock":
        return "bg-red-50"
      default:
        return ""
    }
  }

  const handleAddItem = () => {
    if (!newItem.itemName || !newItem.type || !newItem.size || newItem.stockIn <= 0) {
      alert("يرجى تعبئة جميع الحقول المطلوبة")
      return
    }

    const item: InventoryItem = {
      id: inventory.length > 0 ? Math.max(...inventory.map((i) => i.id)) + 1 : 1,
      itemName: newItem.itemName,
      type: newItem.type,
      size: newItem.size,
      stockIn: newItem.stockIn,
      totalIssues: 0,
      currentStock: newItem.stockIn,
      status: newItem.stockIn <= settings.lowStockThreshold ? "Low Stock" : "Good",
      lastAdded: new Date().toISOString().split("T")[0],
    }

    setInventory([...inventory, item])
    setNewItem({
      itemName: "",
      type: "",
      size: "",
      stockIn: 0,
    })
    setShowAddModal(false)
    alert("تمت إضافة المعدة بنجاح")
  }

  const handleEditItem = (item: InventoryItem) => {
    setEditingItem(item)
    setNewItem({
      itemName: item.itemName,
      type: item.type,
      size: item.size,
      stockIn: item.stockIn,
    })
    setShowAddModal(true)
  }

  const handleUpdateItem = () => {
    if (!editingItem) return

    const updatedInventory = inventory.map((item) =>
      item.id === editingItem.id
        ? {
            ...item,
            itemName: newItem.itemName,
            type: newItem.type,
            size: newItem.size,
            stockIn: newItem.stockIn,
            currentStock: newItem.stockIn - item.totalIssues,
            status:
              newItem.stockIn - item.totalIssues <= 0
                ? "Out of Stock"
                : newItem.stockIn - item.totalIssues <= settings.lowStockThreshold
                  ? "Low Stock"
                  : "Good",
            lastAdded: new Date().toISOString().split("T")[0],
          }
        : item,
    )

    setInventory(updatedInventory)
    setEditingItem(null)
    setNewItem({
      itemName: "",
      type: "",
      size: "",
      stockIn: 0,
    })
    setShowAddModal(false)
    alert("تم تحديث بيانات المعدة بنجاح")
  }

  const handleDeleteItem = (itemId: number) => {
    if (!confirm("هل أنت متأكد من حذف هذه المعدة؟")) return

    setInventory(inventory.filter((item) => item.id !== itemId))
    alert("تم حذف المعدة بنجاح")
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">إدارة المخزون</h1>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          إضافة معدة
        </button>
      </div>

      {/* Inventory Table */}
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">اسم المعدة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">النوع</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المقاس</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الكمية الأولية</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المسلمة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المتبقي</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {inventory.map((item) => (
              <tr key={item.id} className={getRowClass(item.status)}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.itemName}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.type}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.size}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.stockIn}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.totalIssues}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{item.currentStock}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadgeClass(item.status)}`}
                  >
                    {getStatusText(item.status)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2 space-x-reverse">
                  <button onClick={() => handleEditItem(item)} className="text-yellow-600 hover:text-yellow-900">
                    تعديل
                  </button>
                  <button onClick={() => handleDeleteItem(item.id)} className="text-red-600 hover:text-red-900">
                    حذف
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">{editingItem ? "تعديل بيانات المعدة" : "إضافة معدة جديدة"}</h2>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="اسم المعدة"
                value={newItem.itemName}
                onChange={(e) => setNewItem({ ...newItem, itemName: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="text"
                placeholder="النوع"
                value={newItem.type}
                onChange={(e) => setNewItem({ ...newItem, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="text"
                placeholder="المقاس"
                value={newItem.size}
                onChange={(e) => setNewItem({ ...newItem, size: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />

              <input
                type="number"
                placeholder="الكمية الأولية"
                value={newItem.stockIn}
                onChange={(e) => setNewItem({ ...newItem, stockIn: Number.parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="1"
              />
            </div>

            <div className="flex justify-end space-x-2 space-x-reverse mt-6">
              <button
                onClick={() => {
                  setShowAddModal(false)
                  setEditingItem(null)
                  setNewItem({
                    itemName: "",
                    type: "",
                    size: "",
                    stockIn: 0,
                  })
                }}
                className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                إلغاء
              </button>
              <button
                onClick={editingItem ? handleUpdateItem : handleAddItem}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                {editingItem ? "حفظ التعديلات" : "إضافة"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
