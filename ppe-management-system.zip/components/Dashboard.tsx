"use client"

import type { Employee, InventoryItem, Assignment, Settings } from "@/types"

interface DashboardProps {
  employees: Employee[]
  inventory: InventoryItem[]
  assignments: Assignment[]
  settings: Settings
}

export default function Dashboard({ employees, inventory, assignments, settings }: DashboardProps) {
  const totalItems = inventory.length
  const availableItems = inventory.filter((i) => i.status === "Good").length
  const lowStockItems = inventory.filter((i) => i.status === "Low Stock").length
  const outOfStockItems = inventory.filter((i) => i.status === "Out of Stock").length

  const recentAssignments = [...assignments].reverse().slice(0, 5)

  const getStatusText = (status: string) => {
    switch (status) {
      case "Good":
        return "جيد"
      case "Low Stock":
        return "مخزون منخفض"
      case "Out of Stock":
        return "منتهي"
      default:
        return status
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم</h1>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-sm font-medium text-gray-500">إجمالي المعدات</h3>
          <p className="text-3xl font-bold text-gray-900 mt-2">{totalItems}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-green-500">
          <h3 className="text-sm font-medium text-gray-500">المعدات المتاحة</h3>
          <p className="text-3xl font-bold text-green-600 mt-2">{availableItems}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-yellow-500">
          <h3 className="text-sm font-medium text-gray-500">مخزون منخفض</h3>
          <p className="text-3xl font-bold text-yellow-600 mt-2">{lowStockItems}</p>
        </div>

        <div className="bg-white rounded-lg shadow p-6 border-r-4 border-red-500">
          <h3 className="text-sm font-medium text-gray-500">منتهي المخزون</h3>
          <p className="text-3xl font-bold text-red-600 mt-2">{outOfStockItems}</p>
        </div>
      </div>

      {/* Recent Assignments */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">آخر عمليات التسليم</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الموظف
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  المعدات
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  الكمية
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  التاريخ
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentAssignments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
                    لا توجد عمليات تسليم مسجلة
                  </td>
                </tr>
              ) : (
                recentAssignments.map((assignment, index) => (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.employeeName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {assignment.itemName} ({assignment.size})
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.quantity}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.date}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
