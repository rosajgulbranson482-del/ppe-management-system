"use client"

import { useState } from "react"
import type { InventoryItem, Assignment } from "@/types"

interface ReportsPageProps {
  inventory: InventoryItem[]
  assignments: Assignment[]
}

export default function ReportsPage({ inventory, assignments }: ReportsPageProps) {
  const [reportType, setReportType] = useState("all")
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")

  const generateInventoryReport = () => {
    let itemsToReport = inventory
    let title = "تقرير المخزون - جميع المعدات"

    if (reportType === "low") {
      title = "تقرير المخزون - مخزون منخفض"
      itemsToReport = inventory.filter((item) => item.status === "Low Stock")
    } else if (reportType === "out") {
      title = "تقرير المخزون - منتهي المخزون"
      itemsToReport = inventory.filter((item) => item.status === "Out of Stock")
    }

    // Create CSV content
    const headers = ["اسم المعدة", "النوع", "المقاس", "الكمية الأولية", "المسلمة", "المتبقي", "الحالة"]
    const csvContent = [
      headers.join(","),
      ...itemsToReport.map((item) =>
        [
          item.itemName,
          item.type,
          item.size,
          item.stockIn,
          item.totalIssues,
          item.currentStock,
          getStatusText(item.status),
        ].join(","),
      ),
    ].join("\n")

    // Download CSV
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `${title}_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const generateAssignmentsReport = () => {
    let assignmentsToReport = [...assignments].reverse()
    let title = "تقرير التسليمات"

    if (dateFrom && dateTo) {
      title = `تقرير التسليمات من ${dateFrom} إلى ${dateTo}`
      assignmentsToReport = assignmentsToReport.filter((a) => a.date >= dateFrom && a.date <= dateTo)
    }

    // Create CSV content
    const headers = ["التاريخ", "الموظف", "المعدة", "المقاس", "الكمية", "السبب"]
    const csvContent = [
      headers.join(","),
      ...assignmentsToReport.map((assignment) =>
        [
          assignment.date,
          assignment.employeeName,
          assignment.itemName,
          assignment.size,
          assignment.quantity,
          getReasonText(assignment.reason),
        ].join(","),
      ),
    ].join("\n")

    // Download CSV
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", `${title}_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "Good":
        return "جيد"
      case "Low Stock":
        return "مخزون منخفض"
      case "Out of Stock":
        return "منتهي"
      default:
        return status
    }
  }

  const getReasonText = (reason: string) => {
    switch (reason) {
      case "new":
        return "تسليم جديد"
      case "replacement":
        return "استبدال"
      case "lost":
        return "فقدان"
      case "damaged":
        return "تلف"
      default:
        return reason
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">التقارير</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Inventory Report */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">تقرير المخزون</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">نوع التقرير</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">جميع المعدات</option>
                <option value="low">مخزون منخفض</option>
                <option value="out">منتهي المخزون</option>
              </select>
            </div>

            <button
              onClick={generateInventoryReport}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
            >
              📄 إنشاء تقرير
            </button>
          </div>
        </div>

        {/* Assignments Report */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">تقرير التسليمات</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">من تاريخ</label>
              <input
                type="date"
                value={dateFrom}
                onChange={(e) => setDateFrom(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">إلى تاريخ</label>
              <input
                type="date"
                value={dateTo}
                onChange={(e) => setDateTo(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              onClick={generateAssignmentsReport}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700"
            >
              📄 إنشاء تقرير
            </button>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">إحصائيات سريعة</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{inventory.length}</div>
            <div className="text-sm text-gray-600">إجمالي المعدات</div>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{assignments.length}</div>
            <div className="text-sm text-gray-600">إجمالي التسليمات</div>
          </div>

          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">
              {inventory.filter((i) => i.status === "Low Stock").length}
            </div>
            <div className="text-sm text-gray-600">مخزون منخفض</div>
          </div>
        </div>
      </div>
    </div>
  )
}
