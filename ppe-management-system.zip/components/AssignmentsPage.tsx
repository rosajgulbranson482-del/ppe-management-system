"use client"

import type React from "react"

import { useState } from "react"
import type { Employee, InventoryItem, Assignment, Settings } from "@/types"

interface AssignmentsPageProps {
  employees: Employee[]
  inventory: InventoryItem[]
  setInventory: (inventory: InventoryItem[]) => void
  assignments: Assignment[]
  setAssignments: (assignments: Assignment[]) => void
  settings: Settings
}

export default function AssignmentsPage({
  employees,
  inventory,
  setInventory,
  assignments,
  setAssignments,
  settings,
}: AssignmentsPageProps) {
  const [newAssignment, setNewAssignment] = useState({
    employeeId: 0,
    itemId: 0,
    quantity: 1,
    date: new Date().toISOString().split("T")[0],
    reason: "new",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newAssignment.employeeId || !newAssignment.itemId || !newAssignment.quantity || !newAssignment.date) {
      alert("يرجى تعبئة جميع الحقول المطلوبة")
      return
    }

    const employee = employees.find((e) => e.id === newAssignment.employeeId)
    const item = inventory.find((i) => i.id === newAssignment.itemId)

    if (!employee || !item) {
      alert("الموظف أو المعدة غير موجودة")
      return
    }

    if (item.currentStock < newAssignment.quantity) {
      alert(`لا يوجد مخزون كافي. الكمية المتاحة: ${item.currentStock}`)
      return
    }

    // Create new assignment
    const assignment: Assignment = {
      id: assignments.length > 0 ? Math.max(...assignments.map((a) => a.id)) + 1 : 1,
      employeeId: employee.id,
      employeeName: employee.name,
      itemId: item.id,
      itemName: item.itemName,
      size: item.size,
      quantity: newAssignment.quantity,
      date: newAssignment.date,
      reason: newAssignment.reason,
    }

    // Update inventory
    const updatedInventory = inventory.map((invItem) =>
      invItem.id === item.id
        ? {
            ...invItem,
            totalIssues: invItem.totalIssues + newAssignment.quantity,
            currentStock: invItem.currentStock - newAssignment.quantity,
            status:
              invItem.currentStock - newAssignment.quantity <= 0
                ? "Out of Stock"
                : invItem.currentStock - newAssignment.quantity <= settings.lowStockThreshold
                  ? "Low Stock"
                  : "Good",
          }
        : invItem,
    )

    setInventory(updatedInventory)
    setAssignments([...assignments, assignment])

    // Reset form
    setNewAssignment({
      employeeId: 0,
      itemId: 0,
      quantity: 1,
      date: new Date().toISOString().split("T")[0],
      reason: "new",
    })

    alert("تم تسليم المعدة بنجاح")
  }

  const getReasonText = (reason: string) => {
    switch (reason) {
      case "new":
        return "تسليم جديد"
      case "replacement":
        return "استبدال"
      case "lost":
        return "فقدان"
      case "damaged":
        return "تلف"
      default:
        return reason
    }
  }

  const recentAssignments = [...assignments].reverse().slice(0, 20)

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">تسليم المعدات</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Assignment Form */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">تسليم معدة جديدة</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الموظف</label>
              <select
                value={newAssignment.employeeId}
                onChange={(e) => setNewAssignment({ ...newAssignment, employeeId: Number.parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value={0}>اختر موظف...</option>
                {employees
                  .filter((e) => e.status === "Active")
                  .map((employee) => (
                    <option key={employee.id} value={employee.id}>
                      {employee.name} - {employee.company}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">المعدة</label>
              <select
                value={newAssignment.itemId}
                onChange={(e) => setNewAssignment({ ...newAssignment, itemId: Number.parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value={0}>اختر معدة...</option>
                {inventory
                  .filter((i) => i.status !== "Out of Stock")
                  .map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.itemName} ({item.size}) - متوفر: {item.currentStock}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">الكمية</label>
              <input
                type="number"
                min="1"
                value={newAssignment.quantity}
                onChange={(e) => setNewAssignment({ ...newAssignment, quantity: Number.parseInt(e.target.value) || 1 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">تاريخ التسليم</label>
              <input
                type="date"
                value={newAssignment.date}
                onChange={(e) => setNewAssignment({ ...newAssignment, date: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">سبب التسليم</label>
              <select
                value={newAssignment.reason}
                onChange={(e) => setNewAssignment({ ...newAssignment, reason: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                <option value="new">تسليم جديد</option>
                <option value="replacement">استبدال</option>
                <option value="lost">فقدان</option>
                <option value="damaged">تلف</option>
              </select>
            </div>

            <button type="submit" className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700">
              تسجيل التسليم
            </button>
          </form>
        </div>

        {/* Recent Assignments */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold">سجل التسليمات</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">التاريخ</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الموظف</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المعدة</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الكمية</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentAssignments.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-gray-500">
                      لا توجد عمليات تسليم مسجلة
                    </td>
                  </tr>
                ) : (
                  recentAssignments.map((assignment, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.date}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.employeeName}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {assignment.itemName} ({assignment.size})
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{assignment.quantity}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
