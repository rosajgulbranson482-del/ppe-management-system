"use client"

import type { User } from "@/types"

interface SidebarProps {
  currentPage: string
  setCurrentPage: (page: string) => void
  currentUser: User
  onLogout: () => void
  isOpen: boolean
  setIsOpen: (open: boolean) => void
}

const menuItems = [
  { id: "dashboard", name: "لوحة التحكم", icon: "📊" },
  { id: "employees", name: "إدارة الموظفين", icon: "👥" },
  { id: "inventory", name: "إدارة المخزون", icon: "📦" },
  { id: "assignments", name: "تسليم المعدات", icon: "🤝" },
  { id: "reports", name: "التقارير", icon: "📈" },
  { id: "settings", name: "الإعدادات", icon: "⚙️" },
]

export default function Sidebar({
  currentPage,
  setCurrentPage,
  currentUser,
  onLogout,
  isOpen,
  setIsOpen,
}: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setIsOpen(false)} />
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 right-0 z-50 w-64 bg-gray-900 text-white transform transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 bg-gray-800">
            <h3 className="text-xl font-bold text-blue-400">PPE Management System</h3>
            <p className="text-sm text-blue-300 mt-1">Personal Protective Equipment Tracking</p>
            <p className="text-xs text-gray-400 mt-2">إصدار 1.1</p>
          </div>

          {/* Menu Items */}
          <nav className="flex-1 px-4 py-6 space-y-2">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentPage(item.id)
                  setIsOpen(false)
                }}
                className={`w-full flex items-center px-4 py-3 text-right rounded-lg transition-colors ${
                  currentPage === item.id
                    ? "bg-blue-600 text-white"
                    : "text-gray-300 hover:bg-gray-800 hover:text-white"
                }`}
              >
                <span className="ml-3 text-lg">{item.icon}</span>
                <span>{item.name}</span>
              </button>
            ))}
          </nav>

          {/* User Info & Logout */}
          <div className="p-4 border-t border-gray-700">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">{currentUser.name}</span>
              <button onClick={onLogout} className="text-sm text-red-400 hover:text-red-300">
                خروج
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
