export interface User {
  id: number
  username: string
  name: string
  email: string
  role: string
}

export interface Employee {
  id: number
  name: string
  company: string
  title: string
  tel?: string
  shift?: string
  status: string
}

export interface InventoryItem {
  id: number
  itemName: string
  type: string
  size: string
  stockIn: number
  totalIssues: number
  currentStock: number
  status: string
  lastAdded?: string
}

export interface Assignment {
  id: number
  employeeId: number
  employeeName: string
  itemId: number
  itemName: string
  size: string
  quantity: number
  date: string
  reason: string
}

export interface Settings {
  companyName: string
  lowStockThreshold: number
  notificationEmail: string
}
